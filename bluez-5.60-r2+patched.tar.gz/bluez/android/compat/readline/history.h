/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 *
 *  BlueZ - Bluetooth protocol stack for Linux
 *
 *  Copyright (C) 1987-2011 Free Software Foundation, Inc.
 *
 *
 */

#ifndef _HISTORY_H_
#define _HISTORY_H_

static inline void add_history(const char *c)
{
}

#endif
